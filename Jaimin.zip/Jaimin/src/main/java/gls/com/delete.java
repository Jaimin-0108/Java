package gls.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/delete")
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		((ServletResponse) request).setContentType("text/html");
		PrintWriter out= response.getWriter();		
		String name= request.getParameter("mname");
		out.println("Delete operation for Mobile Name:"+name);
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc.mysql://128.66.203.247:3306/imsc7it29","imsc7it29","sumo@123");
			  PreparedStatement pst=  con.prepareStatement("Delete from mobile where mname="+name);
			  pst.executeUpdate();
			  out.println("Mobile Deleted");
			  String linkUrl="display";                
		      out.println("<br> <a href='" + linkUrl + "'>" + "index" + "</a>");
			  
		}
		catch(Exception e)
    	{
    		System.out.println(e);
    	}
		
	}

}